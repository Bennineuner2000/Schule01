'''
@author: Neuner & Zivkovic
'''
from Cargo import CargoShip
from Fighter import FighterShip
from AgriculturePlanets import AgriculturePlanet
from IndustryPlanets import IndustryPlanet
from TechnologyPlanets import TechnologyPlanet
from Planets import Planets
from SpaceShip import SpaceShips
#from random import randint
import random
import sys
import Fighter

ships = {'fighter': 0, 'cargo': 0}
waren = {'iron': 0, 'barley': 0, 'computer':0}
money = 10000
aktuellerPlanet = 0
planetName = 'm'


name = input("Geben Sie ihren Namen ein:")
print("Hallo Captain " + name)

'''
Funktion für einen Zufallsangriff beim Wechseln eines Planeten
'''
def weltraumKampf():
    global name
    #angriffschance = random.randint(1,2)
    angriffsChance = 1
    if angriffsChance == 1:
        fighterAttack = FighterShip().getFighterAttack()
        randomZahl =  random.randint(5,12) / 10
        enemyFighter = (fighterAttack * randomZahl)
        print("Sie werden angegriffen!!!")
        if fighterAttack >= enemyFighter:
            print("Captain "+name+", wir haben den Kampf erfolgreich abgewehrt")
            planetenWahl()
        else:
            print("Captain, wir haben den Kampf leider nicht gewinnen können")
            print("GAME OVER")
            sys.exit(0)
    else:
        planetenWahl()

'''
Die Funktion und das Menü das erscheint wenn man ein Schiff kaufen will
'''  
def schiffKaufen():
    
    global money
    
    print("Um ein Kampfschiff zu kaufen drücken Sie 1")
    print("Um ein Transportschiff zu kaufen drücken Sie 2")
    print("Um zum Menu zu gelangen, drücken sie eine beliebige Taste")
    
    schiffswahl = input("")
    
    if schiffswahl == '1':
        
        fighterKosten = FighterShip().getPrices()
        print("Das Kampfschiff kostet: "+str(fighterKosten))
        
        if(money >= fighterKosten):
            money = money - fighterKosten
            ships['fighter'] += 1
            print("Sie haben ein Kampfschiff gekauft")
            print("Anzahl der Kampfschiffe: " + str(ships['fighter']))
            print("*************************************************")
            print("Ihr aktueller Kontostand: ")
            checkMoney()
        else:
            print("Sie haben nicht genügend Geld!")
            print("*************************************************")
            print("Ihr aktueller Kontostand: ")
            checkMoney()
    elif schiffswahl == '2':
        
        cargoKosten =  CargoShip.getPrices()
        
        print("Das Transportschiff kostet: "+str(cargoKosten))
        if(money >= cargoKosten):
            money = money - cargoKosten
            ships['cargo'] += 1
            print("Sie haben ein Transportschiff gekauft")
            print("Anzahl der Transportschiffe: " + str(ships['cargo']))
            print("*************************************************")
            print("Ihr aktueller Kontostand: ")
            checkMoney()
        else:
            print("Sie haben nicht genügend Geld!")
            print("*************************************************")
            print("Ihr aktueller Kontostand: ")
            checkMoney()
    else:
        print("*************************************************")
        planetenMenu()
'''
Die Funktion und das Menü wenn man ein Waren kaufen will
'''  
def warenKaufen():
    
    global waren
    global money
    global aktuellerPlanet
    
    prices = aktuellerPlanet.getPrices()
    print("*************************************************")
    print("Ihr Kontostand: "+ str(money))
    print("Ihnen steht zur Auswahl:")
    print(prices)
    print("Eisen(1), Computer(2), Gerste(3), um ins Menü zu gelangen drücken Sie die 4")
    warenwahl = input("")
    if warenwahl == "1":
        print("Wieviel möchten Sie kaufen, bitte Anzahl eingeben: ")
        anzahl = int(input(""))
        if(prices['iron']*anzahl <= money):
            money = money-prices['iron']*anzahl
            waren['iron'] += 1 * anzahl
            print("Sie haben insgesamt "+str(waren['iron'])+" Eisen")
            print("*************************************************")
            warenKaufen()
        else:
            print("Sie haben nicht genügend Geld dafür")
            print("*************************************************")
            warenKaufen()
    elif warenwahl == "2":
        print("Wieviel möchten Sie kaufen, bitte Anzahl eingeben")
        anzahl = int(input(""))
        if(prices['computer']*anzahl <= money):
            money = money-prices['computer']*anzahl
            waren['computer'] += 1 * anzahl
            print("Sie haben insgesamt "+str(waren['computer'])+" Computer")
            print("*************************************************")
            warenKaufen()
        else:
            print("Sie haben nicht genügend Geld dafür")
            print("*************************************************")
            warenKaufen()
    elif warenwahl == "3":
        print("Wieviel möchten Sie kaufen, bitte Anzahl eingeben")
        anzahl = int(input(""))
        if(prices['barley']*anzahl <= money):
            money = money-prices['barley']*anzahl
            waren['barley'] += 1 * anzahl
            print("Sie haben insgesamt "+str(waren['barley'])+" Gerste")
            print("*************************************************")
            warenKaufen()
        else:
            print("Sie haben nicht genügend Geld dafür")
            print("*************************************************")
            warenKaufen()
    else:
        print("*************************************************")
        planetenMenu()
'''
Die Funktion und das Menü wenn man Waren verkaufen will
'''  
def warenVerkaufen():
    
    global waren
    global money
    prices = aktuellerPlanet.getPrices()
    
    print("Ihnen steht zur Auswahl: ")
    print(prices)
    print("Eisen(1), Computer(2), Gerste(3), um ins Menü zu gelangen drücken Sie die 4")
    
    warenwahl = input("")
     
    if warenwahl == '1':
        print("Wieviel möchten Sie verkaufen, bitte Anzahl eingeben")
        anzahl = int(input())
        if(waren['iron'] >= anzahl):
            waren['iron'] -= 1 * anzahl
            money = money + prices['iron']*anzahl
            print("Sie haben insgesamt "+str(waren['iron'])+" Eisen")
            print("*************************************************")
            warenVerkaufen()
        else:
            print("Sie haben nicht genügend Ware dafür")
            print("*************************************************")
            warenVerkaufen()
    elif warenwahl == '2':
        print("Wieviel möchten Sie verkaufen, bitte Anzahl eingeben")
        anzahl = int(input())
        if(waren['computer'] >= anzahl):
            waren['computer'] -= 1 * anzahl
            money = money + prices['computer']*anzahl
            print("Sie haben insgesamt "+str(waren['computer'])+" Computern")
            print("*************************************************")
            warenVerkaufen()
        else:
            print("Sie haben nicht genügend Ware dafür")
            print("*************************************************")
            warenVerkaufen()
    elif warenwahl == '3':
        print("Wieviel möchten Sie verkaufen, bitte Anzahl eingeben")
        anzahl = int(input())
        if(waren['barley'] >= anzahl):
            waren['barley'] -= 1 * anzahl
            money = money + prices['barley']*anzahl
            print("Sie haben insgesamt "+str(waren['barley'])+" Gerste")
            print("*************************************************")
            warenVerkaufen()
        else:
            print("Sie haben nicht genügend Ware dafür")
            print("*************************************************")
            warenVerkaufen()
    else:
        print("*************************************************")
        planetenMenu()
'''
zeigt aktuellen Wert der Waren an und gibt ihn aus
'''
def checkWare():
    global waren
        
    print(waren)
    planetenMenu()
'''
zeigt aktuellen Wert des Geldes an und gibt ihn aus
'''  
def checkMoney():
    global money
        
    print(money)
    planetenMenu()

'''
Die Funktion für die Menüauswahl auf einem Planeten
'''  
def planetenMenu():
    print("*************************************************")
    print("Um Schiffe zu Kaufen drücken Sie 1,")
    print("Um Waren zu kaufen drücken Sie 2")
    print("Um Waren zu verkaufen drücken Sie 3")
    print("Um auf einem anderen Planeten zu fliegen drücken Sie 4")
    print("Um Ihren Kontostand zu sehen drücken Sie 5")
    print("Um Ihre Ware zu überprüfen drücken Sie 6")
    print("*************************************************")
    planetenMenuWahl = input("")
    if(planetenMenuWahl == "1"):
        schiffKaufen()
    elif(planetenMenuWahl == "2"):
        warenKaufen()
    elif(planetenMenuWahl == "3"):
        warenVerkaufen()
    elif(planetenMenuWahl == "4"):
        weltraumKampf()
    elif(planetenMenuWahl == "5"):
        checkMoney()
    elif(planetenMenuWahl == "6"):
        checkWare()
    else:
        print("Sie haben ein inkorrektes Zeichen eingegeben")
    
'''
Die Funktion für das Menü zur Auswahl des Planeten
'''  
def planetenWahl():
    
    global planet
    global aktuellerPlanet
    global planetName
    
    print("*************************************************")
    print("Sie müssen wählen, auf welche Art von Planet Sie fliegen möchten")
    print("Um auf einen Agrarplaneten zu starten wählen Sie 1")
    print("Um auf einen Industrieplaneten zu starten wählen Sie 2")
    print("Um auf einen Militärplanetenplaneten zu starten wählen Sie 3")
    print("*************************************************")
    planet = input("")
    
    if planet == "1":
        aktuellerPlanet = AgriculturePlanet()
        planetName = ("A" + str(AgriculturePlanet().getName()))
        print("Sie sind auf einem Agrarplaneten gelandet: "+planetName)
        planetenMenu()
        
    elif planet == "2":
        aktuellerPlanet = IndustryPlanet()
        planetName = ("I" + str(IndustryPlanet().getName()))
        print("Sie sind auf einem Industrieplaneten gelandet: "+planetName)
        planetenMenu()
    
    elif planet == "3":   
        aktuellerPlanet = TechnologyPlanet()
        planetName = ("T" + str(TechnologyPlanet().getName())) 
        print("Sie sind auf einem Technologieplaneten gelandet: "+planetName)
        planetenMenu()
    
    else:
        print("Sie haben ein inkorrektes Zeichen eingegeben")
        planetenWahl()

planetenWahl()
     