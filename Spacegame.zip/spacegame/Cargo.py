'''
Created on 04.05.2018

@author: Neuner

Klasse um den Preis und den Speicher des Schiffes festzulegen
'''
from SpaceShip import SpaceShips
import random
class CargoShip(SpaceShips):
    def __init__(self):
        
        super().__init__()
        self.name = random.randint(1000, 9999)
        self.shipName = ("c" + str(self.name))
        self.cargoStorage = random.randint(50,100)
        
    def getCargoStorage(self):
        return self.cargoStorage
        
    def getCargoName(self):
        return self.shipName