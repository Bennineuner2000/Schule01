'''
Created on 04.05.2018

@author: Neuner

Klasse um den Preis und den Angriffsschaden des Schiffes festzulegen
'''

from SpaceShip import SpaceShips
import random
class FighterShip(SpaceShips):

    def __init__(self): 
        super().__init__()
        self.name = random.randint(1000, 9999)
        self.shipName = ("f" + str(self.name))
        #self.setPrices()
        self.fighterAttack = random.randint(200,400)
        
    def getFighterAttack(self):
        return self.fighterAttack
    
    def getFighterName(self):
        return self.shipName
    
   # def setPrices(self):
        
        #self.prices['FighterShip'] = random.randint(1000,3000)
        