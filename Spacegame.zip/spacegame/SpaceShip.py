'''
Created on 04.05.2018

@author: Neuner
'''
from random import randint

class SpaceShips:
    
    def __init__(self):
        
        self.prices = randint(2000,4500)
         
            
    def getPrices(self):
        return self.prices
    
    def getName(self):
        return self.name
