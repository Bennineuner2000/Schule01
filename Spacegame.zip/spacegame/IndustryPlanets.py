'''
Created on 15.05.2018

@author: Denis

Klasse für das festlegen der Waren des Planeten
'''

from Planets import Planets
import random

class IndustryPlanet(Planets):
       
    def __init__(self):
        
        super().__init__()
        self.setPrices()
    
    def setPrices(self):
        
        self.prices['barley'] =  random.randint(750,1000)
        self.prices['iron'] = random.randint(100,300)
        self.prices['computer'] = random.randint(750,1000)