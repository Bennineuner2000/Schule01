'''
Created on 04.05.2018

@author: Denis

Klasse vererbt waren und preis an einzele Planeten
'''
import random

class Planets:

    def __init__(self):
        '''
        erstellen eines zufalligen Namens 
        '''    
        contents = "abcdđefghijklmnopqrstuvwxyz1234567890"
        pw_length = random.randint(1,14)
        planetName = ""
        
        for i in range(pw_length):
            next_index = random.randrange(len(contents))
            planetName = planetName+contents[next_index]
            
        
        self.planetName = planetName
        
        prices = {'barley': 0, 'iron': 0, 'computer': 0}
        
        self.prices = prices
    
    def getPrices(self):
        return self.prices
    
    def setPrices(self):
        pass
    
    def getName(self):
        return self.planetName